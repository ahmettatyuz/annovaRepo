<?php 
    $title="Erişim Engellendi";
    require "view/header.php";
    require "view/seller/sellerAccessDeniedView.php";
    require "view/footer.php";

?>