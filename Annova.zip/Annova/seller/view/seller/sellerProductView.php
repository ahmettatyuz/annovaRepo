<?php if(!defined("security")){die("Erişim Engellendi");} ?>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-body">
            <h3 class="display-6 text-center">
                Ürün Bilgileri
            </h3>
        </div>

    </div>
</div>