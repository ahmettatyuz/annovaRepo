<?php if(!defined("security")){die("Erişim Engellendi");} ?>
<div class="container mt-5">
    <div class="alert alert-danger" role="alert">
        <h4 class="alert-heading">Erişim Yasak</h4>
        <p>Bu sayfaya girebilmek için bayi hesabı gereklidir !</p>
        <hr>
    </div>
</div>