<?php if(!defined("security")){die("Erişim Engellendi");} ?>
<div class="container mt-5">


    bayi anasayfası
</div>











<script>
    $(document).ready(function(){
        $("#alert").slideDown();
    })
</script>


