<?php 
/*
    admin footer kısmının gorunumu
*/


if (!defined("securityAdmin")) {
    die("Erişim Engellendi");
} ?>
<!-- </div>
</div> -->
</body>

</html>