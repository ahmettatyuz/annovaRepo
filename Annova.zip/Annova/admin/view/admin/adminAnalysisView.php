<?php 
/*
    admin analiz ekranı gorunum dosyasi
*/

if(!defined("securityAdmin")){die("Erişim Engellendi");} ?>
<div class="container mt-5">
analiz bölümü
</div>
