<!-- erişim engellendi gorunumu -->
<div class="container mt-5">
    <div class="alert alert-danger" role="alert">
        <h4 class="alert-heading">Erişim Yasak</h4>
        <p>Bu sayfaya girebilmek için yeterli admin yetkisi gereklidir !</p>
        <a href="adminlogout.php">Admin Girişi</a>
        <hr>
    </div>
</div>