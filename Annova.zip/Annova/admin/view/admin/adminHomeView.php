<?php 
/*
    admin anasayfa ekranı gorunumu
*/
if (!defined("securityAdmin")) {
    die("Erişim Engellendi");
    
} ?>


<div class="col-sm-10 col-md-10 col-xl-11 col-12 d-flex flex-column h-sm-100 mx-auto">
    <div class="row overflow-auto ">

        <div class="container mt-5">
            admin anasayfası
            <br>
        </div>
    </div>
</div>