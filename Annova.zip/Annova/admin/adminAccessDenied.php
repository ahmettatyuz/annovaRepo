<?php 
/*
    admin erişim engellendi sayfası
    bu sayfanın gorunumunu degistirmek icin adminAccessView.php dosyasına gidilmelidir.
*/
    $title = "Erişim Engellendi";
    require "view/admin/adminAccessDeniedView.php";

?>